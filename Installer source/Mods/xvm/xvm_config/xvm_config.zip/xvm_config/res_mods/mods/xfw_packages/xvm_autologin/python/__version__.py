# This file was created automatically from build script
__xvm_version__ = '8.3.1'
__wot_version__ = '1.7.1.2'
__revision__ = '22'
__branch__ = 'master'
__node__ = 'bc92656ef8f25ef7118b7fb43caaf991499304c2'
__development__ = 'True'
